package com.example.genderdecoder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GenderdecoderApplication {

	public static void main(String[] args) {
		SpringApplication.run(GenderdecoderApplication.class, args);
	}

}
